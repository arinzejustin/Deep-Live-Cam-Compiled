name = 'Deep-Live-Cam'
version = '2.0.1c'
edition = 'GitHub Edition'
